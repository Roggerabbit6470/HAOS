export class AuthenticationError extends Error {}
